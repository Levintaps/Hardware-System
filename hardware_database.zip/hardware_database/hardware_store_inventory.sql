-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hardware_store
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(50) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `quantity` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'Hammer','H01','Household Tools',150,'142'),(2,'Tape Measure','TM02','Household Tools',120,'100'),(3,'Sand Paper','SP03','Household Tools',15,'100'),(4,'Toolbox','TB04','Household Tools',350,'93'),(5,'Pliers','P05','Household Tools',180,'42'),(6,'Coco Lumber','CL01','Wood Product',86,'100'),(7,'Good Lumber','GL02','Wood Product',56,'100'),(8,'Marine Plywood','MP03','Wood Product',417,'100'),(9,'Plywood Ordinary','PO04','Wood Product',310,'100'),(10,'Marine Plywood Local','MPL05','Wood Product',494,'100'),(11,'Door Jamb Mirante','DJM01','Doors & Jambs',1440,'50'),(12,'Lotus Hole Saw Set','LHSS02','Doors & Jambs',293,'100'),(13,'PVC Door with Louver White','DLW03','Doors & Jambs',1755,'100'),(14,'Powerhouse Door Hole Saw','PDHS04','Doors & Jambs',587,'100'),(15,'Door Jamb Tanguile','DJT05','Doors & Jambs',2700,'100'),(16,'Tubular Bar GI','TBGI01','Steel',250,'100'),(17,'C-Purlins BI','CPBI02','Steel',300,'100'),(18,'Angle Bar','AB03','Steel',310,'100'),(19,'Steel Matting','SM04','Steel',500,'100'),(20,'G.I Pipe Local S20','GPS05','Steel',283,'100'),(21,'Gardner','G01','Drywall & Ceiling',385,'97'),(22,'BlInd Rivet','BR02','Drywall & Ceiling',290,'100'),(23,'Gypsum Board Knauf','GBK04','Drywall & Ceiling',550,'100'),(24,'Metal Tracks','MT03','Drywall & Ceiling',110,'100'),(25,'L - Molding 5','LM05','Drywall & Ceiling',250,'100'),(26,'Concrete Hollow Block','CHB','Concrete Masonry',25,'200'),(27,'Eagle Cement Advance','ECA02','Concrete Masonry',232,'100'),(28,'White Sand','WS03','Concrete Masonry',600,'100'),(29,'Republic Cement','RC04','Concrete Masonry',245,'100'),(30,'Gravel','G05','Concrete Masonry',2100,'100'),(31,'Camel Drawer Lock','CDL01','Door Cab Hardware',78,'100'),(32,'Golden Cup Hinges','GCH02','Door Cab Hardware',48,'100'),(33,'Oval Wardrobe Rail Support','OWRS03','Door Cab Hardware',30,'100'),(34,'Amerilock Door Knob Al-588 AB','ADK04','Door Cab Hardware',270,'100'),(35,'Drawer Guide 2x12 Black Hafele','DGBH05','Door Cab Hardware',590,'100'),(36,'Deformed Bar G33','DBG3301','Rebars & G.I Wires',650,'100'),(37,'GI Wire #16','GIW02','Rebars & G.I Wires',900,'100'),(38,'Deformed Bar G60','DBG6003','Rebars & G.I Wires',176,'100'),(39,'Tailin Cutting Wheel 14','TCW04','Rebars & G.I Wires',198,'100'),(40,'Tyrolit Metal Cutting Disc','TMCD05','Rebars & G.I Wires',630,'100'),(41,'Galvanize Hose Clamp','GHC01','Plumbing Pipes',500,'100');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-01 20:15:53
