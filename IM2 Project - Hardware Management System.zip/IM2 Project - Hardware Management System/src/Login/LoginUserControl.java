/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

//import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author levin
 */
public class LoginUserControl {
    String sql;
    ResultSet rs;
    Connection con;
    PreparedStatement pst;
    Statement st;

    public LoginUserControl(){
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HARDWARE_STORE", "root", "password");
        st = con.createStatement();
    }catch(ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(null, "database connection failed, an error occured on \n + e");
    }
  }
    
    public List cartlogin (String username, String password){
        List logLogin = new ArrayList();
        int result;
        String sql = "SELECT username, password, role FROM user WHERE username='"+ username + "' and password='"+ password +"'";
        try{
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                userdata ud = new userdata();
                ud.setusername(rs.getString("username"));
                ud.setpassword(rs.getString("password"));
                ud.setrole(rs.getString("role"));
                logLogin.add(ud);
            }
        }catch(Exception e){
                JOptionPane.showMessageDialog(null, "There was a login error..." + e);
        }
        return logLogin;
}

   
}
