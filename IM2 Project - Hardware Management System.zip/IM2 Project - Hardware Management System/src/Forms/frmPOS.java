/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Forms;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import net.proteanit.sql.DbUtils;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.Timer;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author levin
 */
public class frmPOS extends javax.swing.JInternalFrame {
    String sql;
    ResultSet rs;
    Connection con;
    PreparedStatement pst;
    /**
     * Creates new form frmPOS
     */
    public frmPOS() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/5-getWidth()/4,size.height/6 - getHeight()/4);
        //POS();
        //DisplayTable();
        showDate();
        clock();
        //lblDate.setText("Date: " + date);
        //lblTime.setText("Time: " + formattedTime);
        //time.setText(formattedTime);
        //timer.start();
    }
    
    private void tblHeader(){
        JTableHeader thead = tblPOS.getTableHeader();
        thead.setForeground(Color.BLUE);
        thead.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        TableColumn col = tblPOS.getColumnModel().getColumn(0); //Product Code
        col.setPreferredWidth(100);
        TableColumn col1 = tblPOS.getColumnModel().getColumn(1); //Item Name
        col1.setPreferredWidth(100);
        TableColumn col2 = tblPOS.getColumnModel().getColumn(2); //Price
        col2.setPreferredWidth(40);
        TableColumn col3 = tblPOS.getColumnModel().getColumn(3); //Quantity
        col3.setPreferredWidth(40);
        TableColumn col4 = tblPOS.getColumnModel().getColumn(4); //Sub-total
        col4.setPreferredWidth(60);
    }
    
    private void  DisplayTable(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HARDWARE_STORE?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC","root","password");

            String sql = "SELECT barcode AS 'Product Code', product_name AS 'Item Name', amount AS 'Price', quantity AS 'Quantity', total AS 'Sub-Total' FROM sales ORDER BY ID ASC";
            PreparedStatement pst = con.prepareStatement(sql);
            
            ResultSet rs = pst.executeQuery();
            tblPOS.setModel(DbUtils.resultSetToTableModel(rs));
            
            tblHeader();
         }catch (ClassNotFoundException | SQLException e)
         {
           JOptionPane.showMessageDialog(null, e);
         }
    }
    
    public void POS(){
       // start and display total records in database
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HARDWARE_STORE?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC","root","password");
            pst = con.prepareStatement("SELECT COUNT(*) FROM sales");
            rs = pst.executeQuery();
            while(rs.next()){
                int count = rs.getInt(1);
                //lblCount.setText(String.valueOf(count));
            }
        }catch(ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    void showDate(){
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy");
        lblDate.setText(s.format(d));
    }
    
    public void clock(){
        Thread clock = new Thread(){
            public void run(){
                try{
                    for(;;){
                        Calendar cal = new GregorianCalendar();
                        
                        int Hours = cal.get(Calendar.HOUR_OF_DAY);
                        int minutes = cal.get(Calendar.MINUTE);
                        int seconds = cal.get(Calendar.SECOND);
                        
                        lblTime.setText(Hours+":"+minutes+":"+seconds);
                        
                        sleep(1000);
                    }
                }catch(Exception e){
                    
                }
            }
        };
        clock.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPOS = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtPC = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        txtitemname = new javax.swing.JTextField();
        txtPrice = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtPayment = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        txtChange = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtAmount = new javax.swing.JTextField();
        txtquantity = new javax.swing.JSpinner();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtReceipt = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        btnCancel = new javax.swing.JButton();
        lblDate = new javax.swing.JLabel();
        lblTime = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btnPrint = new javax.swing.JButton();
        tbnNew = new javax.swing.JButton();

        setBackground(new java.awt.Color(153, 255, 153));
        setClosable(true);
        setAlignmentX(5.0F);
        setAlignmentY(1.0F);

        jTextField2.setEditable(false);
        jTextField2.setBackground(new java.awt.Color(0, 153, 255));
        jTextField2.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 48)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(255, 255, 255));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.setText("Hardware Store");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        tblPOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Code", "Item Name", "Price", "Quantity", "Sub-Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPOS);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PRODUCT CODE");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("PRODUCT NAME");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("PRICE");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("QUANTITY");

        txtPC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPCKeyPressed(evt);
            }
        });

        jTextField3.setText("jTextField1");

        txtitemname.setEditable(false);

        txtPrice.setEditable(false);
        txtPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPriceActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("TOTAL AMOUNT");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("PAYMENT");

        txtPayment.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtPayment.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPaymentKeyPressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("CHANGE");

        txtTotal.setEditable(false);
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        txtChange.setEditable(false);
        txtChange.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("AMOUNT");

        txtquantity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                txtquantityStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtitemname, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtquantity, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtPC, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtChange))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtPayment))
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtTotal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPC, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtitemname, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtChange, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtquantity)
                    .addComponent(txtAmount))
                .addGap(20, 20, 20))
        );

        txtReceipt.setColumns(20);
        txtReceipt.setRows(5);
        jScrollPane2.setViewportView(txtReceipt);

        btnCancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnCancel.setText("Void");
        btnCancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCancelMouseClicked(evt);
            }
        });

        lblDate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblTime.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        btnAdd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblDate, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(lblTime, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(btnAdd)
                        .addGap(46, 46, 46)
                        .addComponent(btnCancel)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancel)
                    .addComponent(btnAdd))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTime, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        btnPrint.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnPrint.setText("Print");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        tbnNew.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tbnNew.setText("New");
        tbnNew.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbnNewMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(tbnNew, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(tbnNew, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(1, 1, 1))
                    .addComponent(btnPrint, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)))
            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 1011, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPriceActionPerformed

    private void txtPCKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPCKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            String name = txtPC.getText();
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HARDWARE_STORE?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC","root","password");
                pst = con.prepareStatement("SELECT * FROM inventory WHERE barcode=?");
                pst.setString(1, name);
                rs = pst.executeQuery();
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(this, "No barcode in database");
                    txtPC.setText("");
                    txtPC.requestFocus();
                }else{
                String productname = rs.getString("product_name");
                String unitprice =rs.getString("amount");
                
                txtitemname.setText(productname.trim());
                txtPrice.setText(unitprice.trim());
                //txtquantity.requestFocus();
            }
            }catch(ClassNotFoundException ex){
                Logger.getLogger(frmPOS.class.getName()).log(Level.SEVERE, null, ex);
            }catch(SQLException ex){
                Logger.getLogger(frmCategory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }//GEN-LAST:event_txtPCKeyPressed
    
    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

        try {
        DefaultTableModel model = (DefaultTableModel) tblPOS.getModel();

        // Add a new row to the table
        model.addRow(new Object[]{
            txtPC.getText(),
            txtitemname.getText(),
            txtPrice.getText(),
            txtquantity.getValue().toString(),
            txtAmount.getText()
        });
        int sum = 0;
        for (int i = 0; i < tblPOS.getRowCount(); i++) {
            sum += Double.parseDouble(tblPOS.getValueAt(i, 4).toString());
        }

        // Update the txtTotal text field with the calculated sum
        txtTotal.setText(Double.toString(sum));

        // Clear input fields
        txtPC.setText("");
        txtitemname.setText("");
        txtPrice.setText("");
        txtAmount.setText("");
        txtquantity.setValue(0);
        txtPC.requestFocus();
    } catch (NumberFormatException e) {
        System.err.println("Invalid number format: " + e.getMessage());
    } catch (Exception e) {
        System.err.println("Error: " + e.getMessage());
       
    }
    }//GEN-LAST:event_btnAddActionPerformed

    private void txtquantityStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_txtquantityStateChanged
        // TODO add your handling code here:
        try {
        int qty = (int) txtquantity.getValue();
        double price = Double.parseDouble(txtPrice.getText());
        double total = qty * price;

        txtAmount.setText(String.valueOf(total));
    } catch (NumberFormatException e) {
        System.err.println("Invalid number format: " + e.getMessage());
    }
    }//GEN-LAST:event_txtquantityStateChanged

    public void Payment(){
        double totalAmount = Double.parseDouble(txtTotal.getText());
        double payment = Double.parseDouble(txtPayment.getText());
        double change = payment - totalAmount;

        txtChange.setText(String.format("%.2f", change));
    }
    
    public void Receipt(){
        
        String total = txtTotal.getText();
        String pay = txtPayment.getText();
        String bal = txtChange.getText();
        DefaultTableModel model = new DefaultTableModel();
        model = (DefaultTableModel)tblPOS.getModel();
         
         txtReceipt.setText(txtReceipt.getText() + "*****************************************************************************************\n");
         txtReceipt.setText(txtReceipt.getText() + "                                        OFFICIAL RECEIPT                          \n");
         txtReceipt.setText(txtReceipt.getText() + "*****************************************************************************************\n");
         
          txtReceipt.setText(txtReceipt.getText() + "Product" + "\t" + "   Price   " + "\t" +   "Quantity"   + "\t" +   "Amount    " + "\n"  );
          
          
          for(int i = 0; i < model.getRowCount(); i++)
          {
              
              String pname = (String)model.getValueAt(i, 1);
              String price = (String)model.getValueAt(i, 2);
              String qty = (String)model.getValueAt(i, 3);
              String amount = (String)model.getValueAt(i, 4); 
              
           txtReceipt.setText(txtReceipt.getText() + pname  + "\t" + price + "\t" + qty + "\t" + amount  + "\n"  );
    
          }
          
          txtReceipt.setText(txtReceipt.getText() + "\n");     
          
          txtReceipt.setText(txtReceipt.getText() + "\t" + "\t" + "\t" + "Total :" + total + "\n");
          txtReceipt.setText(txtReceipt.getText() + "\t" + "\t" + "\t" + "Cash :" + pay + "\n");
          txtReceipt.setText(txtReceipt.getText() + "\t" + "\t" + "\t" + "Change :" + bal + "\n");
          txtReceipt.setText(txtReceipt.getText() + "\n");
          txtReceipt.setText(txtReceipt.getText() + "***************************************************************************\n");
          txtReceipt.setText(txtReceipt.getText() + "                                THANK YOU, COME AGAIN!             \n");
          
    }
    
    
    
    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        // TODO add your handling code here:
        try{
            //Payment();
            //Receipt();
            txtReceipt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(frmPOS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void btnCancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelMouseClicked
        // TODO add your handling code here:
        try {
            //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBPOS?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC","root","lollipopko");

            int row = tblPOS.getSelectedRow();
            if (row == -1) {
            JOptionPane.showMessageDialog(null, "Please select a transaction to cancel.");
            return;
            }
            //String value=(tblPOS.getModel().getValueAt(row, 0).toString());
            txtTotal.setText("");
            txtPrice.setText("");
            txtitemname.setText("");
            txtPC.setText("");
            txtPC.requestFocus();
            //String sql = "DELETE FROM sales WHERE id = ?";
            //PreparedStatement pst = con.prepareStatement(sql);
            //pst.setString(1, value);
            
            //pst.executeUpdate();
            
            DefaultTableModel model = (DefaultTableModel) tblPOS.getModel();
            model.removeRow(row);
            
            int sum = 0;
            for (int i = 0; i < tblPOS.getRowCount(); i++) {
                sum += Double.parseDouble(tblPOS.getValueAt(i, 4).toString());
            }

                // Update the txtTotal text field with the calculated sum
            txtTotal.setText(Double.toString(sum));
            
            //txtTotal.getText();
            JOptionPane.showMessageDialog(null, "Item has been cancelled");
            //DisplayTable();
            POS();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        
        }                                      
    }//GEN-LAST:event_btnCancelMouseClicked

    private void txtPaymentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPaymentKeyPressed
        // TODO add your handling code here:
        
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
        Receipt();
        
        DateTimeFormatter dt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String date = dt.format(now);
        
        DecimalFormat df1 = new DecimalFormat("0.00");
        
        double totalAmount = Double.parseDouble(txtTotal.getText());
        double payment = Double.parseDouble(txtPayment.getText());
        double change = payment - totalAmount;

        txtChange.setText(String.format("%.2f", change));
        
        DefaultTableModel model = (DefaultTableModel) tblPOS.getModel();
        if(model.getRowCount()==0){
            JOptionPane.showMessageDialog(this, "Table is empty");
        }else{
            String barcode, product_name, amount, quantity, total;
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HARDWARE_STORE?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC","root","password");
                for(int i = 0; i<model.getRowCount(); i++){
                    barcode = model.getValueAt(i, 0).toString();
                    product_name = model.getValueAt(i, 1).toString();
                    amount = model.getValueAt(i, 2).toString();
                    quantity = model.getValueAt(i, 3).toString();
                    total = model.getValueAt(i, 4).toString();
                    
                    int row = tblPOS.getRowCount();
                    String sql = "INSERT INTO sales (barcode, product_name, amount, quantity, total, date_of_sales) values (?, ?, ?, ?, ?, ?)";
                    pst = con.prepareStatement(sql);
                    
                    pst.setString(1, barcode);
                    pst.setString(2, product_name);
                    pst.setString(3, amount);
                    pst.setString(4, quantity);
                    pst.setString(5, total);
                    pst.setString(6, date);
                    pst.execute();
                }
                String sql2 = "UPDATE inventory SET quantity = quantity - ? WHERE barcode=?";
                pst = con.prepareStatement(sql2);
                for(int i = 0; i<tblPOS.getRowCount(); i++){
                    barcode = (String)tblPOS.getValueAt(i, 0);
                    quantity = (String)tblPOS.getValueAt(i, 3);
                    
                    pst.setString(1, quantity);
                    pst.setString(2, barcode);
                    pst.execute();
                }
                pst.addBatch();
                }catch(ClassNotFoundException | SQLException e){
                }
                model.setRowCount(0);
        }
        
        
        }
    }//GEN-LAST:event_txtPaymentKeyPressed

    private void tblPOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPOSMouseClicked
        // TODO add your handling code here:
        DefaultTableModel updatetable = (DefaultTableModel)tblPOS.getModel();
        int rows = tblPOS.getSelectedRow();
        txtPC.setText(updatetable.getValueAt(rows, 0).toString());
        txtPC.setEditable(true);
    }//GEN-LAST:event_tblPOSMouseClicked

    private void tbnNewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbnNewMouseClicked
        // TODO add your handling code here:
        txtReceipt.setText("");
        txtTotal.setText("");
        txtPayment.setText("");
        txtChange.setText("");
        txtquantity.setValue(0);
    }//GEN-LAST:event_tbnNewMouseClicked
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnPrint;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblTime;
    private javax.swing.JTable tblPOS;
    private javax.swing.JButton tbnNew;
    private javax.swing.JTextField txtAmount;
    private javax.swing.JTextField txtChange;
    private javax.swing.JTextField txtPC;
    private javax.swing.JTextField txtPayment;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextArea txtReceipt;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtitemname;
    private javax.swing.JSpinner txtquantity;
    // End of variables declaration//GEN-END:variables

        
}
